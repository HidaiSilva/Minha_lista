/*
 * Criado por SharpDevelop.
 * Usu�rio: Macoratti
 * Data: 28/5/2008
 * Hora: 20:18
 * 
 * Para alterar este modelo use Ferramentas | Op��es | Codifica��o | Editar Cabe�alhos Padr�o.
 */

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Data; 
using System.Data.OleDb;

namespace c_AcessoBD
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
			
	public partial class MainForm : Form
	{
	
		private OleDbConnection Conn; 
		private OleDbDataAdapter da; 
		private DataSet ds; 
		
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
				
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		private void iniciaAcesso()
		{
			ds = new DataSet(); 
    
    		Conn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\dados\\" + txtDataBase.Text); 
    
    		try { 
        		Conn.Open(); 
    			} 
    			catch (System.Exception e) { 
        			MessageBox.Show(e.Message.ToString()); 
    			} 
    
    		if (Conn.State == ConnectionState.Open) { 
        		da = new OleDbDataAdapter("SELECT * from " + txtTabela.Text, Conn); 
        		da.Fill(ds, "Categories"); 
        		dgvDados.DataSource = ds; 
        		dgvDados.DataMember = "Categories"; 
    		} 
		}
		
		void Button1Click(object sender, EventArgs e)
		{
			iniciaAcesso();
		}
	}
}
